# CBLUR

A harmless browser-based prank virus that runs a **CBLUR** infection sequence, then hands off to a classic **Salinewin.exe**-style dissolving salt crystal effect.

## What it does

1. **CBLUR phase** — Fake virus scanner with progressive blur, glitch, and screen shake effects
2. **Salinewin.exe phase** — Switches to a fake Windows desktop and starts the classic salt-crystal dissolution animation
3. **Reveal** — Ends with a clear "Gotcha" message

## Important

This is **100% harmless**. It is pure HTML, CSS, and JavaScript that only runs in the browser tab.  
No files are modified, nothing is installed, and closing the tab ends it instantly.

## How to run

### Option 1: Open locally
Just open `index.html` in any modern browser.

### Option 2: GitHub Pages
1. Push this repo to GitHub
2. Go to Settings → Pages
3. Select the main branch and `/ (root)`
4. Your prank will be live at `https://yourusername.github.io/repo-name/`

## Files

- `index.html` — The full prank (self-contained)

## Disclaimer

For entertainment and nostalgia only. Do not use to scare people without their consent.
